# Change Log

FABRIC testbed extensions changlog

##  [1.3.6] - 2022-12-01

 
### Added
- FABLIB:  Show and list examples
- FABLIB:  Graphical list examples
 
### Changed
 
- FABLIB:  Execute example with live output



 
 
 
## [1.3.5] - 2022-10-25
  
Older and not included in change log
