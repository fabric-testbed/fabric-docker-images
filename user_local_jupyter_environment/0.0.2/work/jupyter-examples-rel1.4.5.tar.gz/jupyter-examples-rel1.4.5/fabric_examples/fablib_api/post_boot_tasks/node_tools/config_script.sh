#!/bin/bash

echo "Hello, FABRIC" > post_boot_output.txt

sudo dnf install -y tcpdump