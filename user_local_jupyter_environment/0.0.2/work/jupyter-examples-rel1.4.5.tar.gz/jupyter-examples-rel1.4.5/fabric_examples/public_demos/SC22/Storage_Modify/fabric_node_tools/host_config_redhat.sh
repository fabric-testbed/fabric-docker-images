#!/bin/bash

# Install Packages
sudo yum install -y -q epel-release
sudo yum install -y -q net-tools iperf3 iftop httpd iproute-tc pciutils


